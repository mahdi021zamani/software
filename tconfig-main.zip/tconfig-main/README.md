# Free V2RAY Proxy List
توسط این‌ابزار می‌تونین به کانفیگ‌های رایگان گردآوری‌شده دسترسی داشته باشین. این‌کانفیگ‌ها به‌صورت خودکار و منظم، بدون دخل‌وتصرف از یه‌سری کانال تلگرامی جمع‌آوری میشن و برای رعایت مسائل امنیتی توصیه میشه تنها برای مصارف عادی ازشون استفاده کنین.

![image](https://github.com/user-attachments/assets/4600b7c1-a10a-4b7d-8768-865a78241f64)

دریافت کانفیگ رایگان:\
https://ircfspace.github.io/tconfig

گردآوری‌شده از طریق:\
https://github.com/soroushmirzaei/telegram-configs-collector
